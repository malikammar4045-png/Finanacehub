import { useEffect, useRef, useState } from 'react';
import { Check, TrendingUp, Users, Award } from 'lucide-react';

const About = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const features = [
    'Zero commission trading',
    'Expert portfolio guidance',
    'Real-time market insights',
  ];

  const stats = [
    { icon: TrendingUp, value: '$2B+', label: 'Assets Managed', position: 'top-right' },
    { icon: Users, value: '500K+', label: 'Active Investors', position: 'bottom-left' },
    { icon: Award, value: '99%', label: 'Satisfaction', position: 'hidden' },
  ];

  return (
    <section
      id="about"
      ref={sectionRef}
      className="py-24 lg:py-36 bg-white overflow-hidden"
    >
      <div className="max-w-[1460px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-24 items-center">
          {/* Content */}
          <div className="max-w-xl">
            {/* Subtitle */}
            <span
              className="inline-block text-primary text-sm font-semibold tracking-wider uppercase mb-4"
              style={{
                animation: isVisible ? 'typewriter 0.8s linear forwards' : 'none',
                opacity: 0,
              }}
            >
              About Us
            </span>

            {/* Title */}
            <h2
              className="text-3xl sm:text-4xl lg:text-h2 font-bold text-secondary mb-6"
              style={{
                animation: isVisible ? 'fadeUp 0.6s 0.2s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
                opacity: 0,
              }}
            >
              Building Financial{' '}
              <span className="text-gradient">Freedom</span> For Everyone
            </h2>

            {/* Description */}
            <p
              className="text-gray text-lg mb-8"
              style={{
                animation: isVisible ? 'fadeUp 0.6s 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
                opacity: 0,
              }}
            >
              We believe everyone deserves access to professional-grade investment
              tools and education. Our platform combines cutting-edge technology
              with expert guidance to help you achieve your financial goals.
            </p>

            {/* Features */}
            <div className="space-y-4">
              {features.map((feature, index) => (
                <div
                  key={feature}
                  className="flex items-center gap-4 group"
                  style={{
                    animation: isVisible
                      ? `slideLeft 0.5s ${0.6 + index * 0.1}s cubic-bezier(0.16, 1, 0.3, 1) forwards`
                      : 'none',
                    opacity: 0,
                  }}
                >
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0 group-hover:bg-secondary transition-colors duration-300">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-secondary font-medium group-hover:translate-x-1 transition-transform duration-300">
                    {feature}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Image */}
          <div
            className="relative"
            style={{
              animation: isVisible ? 'scaleReveal 0.8s 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="/images/about-image.jpg"
                alt="Team collaboration"
                className="w-full h-auto object-cover"
              />
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-tr from-secondary/20 to-transparent" />
            </div>

            {/* Floating Stats Cards */}
            {stats.slice(0, 2).map((stat, index) => (
              <div
                key={stat.label}
                className={`absolute ${
                  stat.position === 'top-right'
                    ? '-top-6 -right-6 lg:-right-10'
                    : 'bottom-10 -left-6 lg:-left-10'
                } bg-white rounded-xl shadow-xl p-4 lg:p-5 animate-float`}
                style={{
                  animation: isVisible
                    ? `popFloat 0.6s ${0.8 + index * 0.2}s cubic-bezier(0.68, -0.55, 0.265, 1.55) forwards, float 4s ${1.2 + index * 0.5}s ease-in-out infinite`
                    : 'none',
                  opacity: 0,
                }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 lg:w-12 lg:h-12 bg-primary/10 rounded-full flex items-center justify-center">
                    <stat.icon className="w-5 h-5 lg:w-6 lg:h-6 text-primary" />
                  </div>
                  <div>
                    <div className="text-xl lg:text-2xl font-bold text-secondary">{stat.value}</div>
                    <div className="text-xs lg:text-sm text-gray">{stat.label}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes typewriter {
          from {
            opacity: 0;
            clip-path: inset(0 100% 0 0);
          }
          to {
            opacity: 1;
            clip-path: inset(0 0% 0 0);
          }
        }
        
        @keyframes slideLeft {
          from {
            opacity: 0;
            transform: translateX(-30px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        
        @keyframes scaleReveal {
          from {
            opacity: 0;
            transform: scale(0.9);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
        
        @keyframes popFloat {
          from {
            opacity: 0;
            transform: scale(0) translateY(20px);
          }
          to {
            opacity: 1;
            transform: scale(1) translateY(0);
          }
        }
      `}</style>
    </section>
  );
};

export default About;
