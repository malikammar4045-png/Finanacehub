import { useEffect, useRef, useState } from 'react';
import { Check, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Pricing = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const plans = [
    {
      name: 'Starter',
      price: '9',
      description: 'Perfect for beginners',
      features: [
        'Basic budget tracking',
        '5 crypto price alerts',
        '3 side hustle guides',
        'Email support',
        'Monthly reports',
      ],
      highlighted: false,
      cta: 'Get Started',
    },
    {
      name: 'Growth',
      price: '29',
      description: 'Most Popular',
      features: [
        'Advanced budget analytics',
        'Unlimited crypto alerts',
        'All side hustle guides',
        'Priority support',
        'Weekly reports',
        'Portfolio tracking',
        'Investment recommendations',
      ],
      highlighted: true,
      cta: 'Start Free Trial',
    },
    {
      name: 'Pro',
      price: '79',
      description: 'For serious investors',
      features: [
        'Everything in Growth',
        '1-on-1 financial coaching',
        'Custom investment strategies',
        'API access',
        'White-label reports',
        'Team collaboration',
        'Dedicated account manager',
      ],
      highlighted: false,
      cta: 'Contact Sales',
    },
  ];

  return (
    <section
      id="pricing"
      ref={sectionRef}
      className="py-24 lg:py-36 bg-white overflow-hidden"
    >
      <div className="max-w-[1460px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span
            className="inline-block text-primary text-sm font-semibold tracking-wider uppercase mb-4"
            style={{
              animation: isVisible ? 'fadeUp 0.7s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            Pricing
          </span>
          <h2
            className="text-3xl sm:text-4xl lg:text-h2 font-bold text-secondary mb-6"
            style={{
              animation: isVisible ? 'fadeUp 0.7s 0.1s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            Choose Your{' '}
            <span className="text-gradient">Investment Plan</span>
          </h2>
          <p
            className="text-gray text-lg"
            style={{
              animation: isVisible ? 'fadeUp 0.7s 0.2s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            Flexible plans designed for every stage of your financial journey.
            Start free, upgrade when you are ready.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid lg:grid-cols-3 gap-8 perspective-1000">
          {plans.map((plan, index) => (
            <div
              key={plan.name}
              className={`relative rounded-2xl p-8 transition-all duration-500 hover:-translate-y-3 ${
                plan.highlighted
                  ? 'bg-secondary text-white shadow-2xl scale-105 lg:scale-110 z-10'
                  : 'bg-white border border-secondary/10 shadow-lg hover:shadow-xl'
              }`}
              style={{
                animation: isVisible
                  ? `flipIn3D 0.8s ${0.3 + index * 0.2}s cubic-bezier(0.16, 1, 0.3, 1) forwards`
                  : 'none',
                opacity: 0,
                transformStyle: 'preserve-3d',
              }}
            >
              {/* Popular Badge */}
              {plan.highlighted && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <span className="inline-flex items-center gap-1 bg-primary text-white text-sm font-semibold px-4 py-1.5 rounded-full animate-pulse-glow">
                    <Sparkles className="w-4 h-4" />
                    Most Popular
                  </span>
                </div>
              )}

              {/* Plan Header */}
              <div className="text-center mb-8">
                <h3 className={`text-xl font-bold mb-2 ${plan.highlighted ? 'text-white' : 'text-secondary'}`}>
                  {plan.name}
                </h3>
                <p className={`text-sm mb-4 ${plan.highlighted ? 'text-white/70' : 'text-gray'}`}>
                  {plan.description}
                </p>
                <div className="flex items-baseline justify-center gap-1">
                  <span className={`text-sm ${plan.highlighted ? 'text-white/70' : 'text-gray'}`}>$</span>
                  <span
                    className={`text-5xl font-bold ${plan.highlighted ? 'text-white' : 'text-secondary'}`}
                    style={{
                      animation: isVisible ? `countUp 0.8s ${0.8 + index * 0.1}s cubic-bezier(0.16, 1, 0.3, 1) forwards` : 'none',
                    }}
                  >
                    {plan.price}
                  </span>
                  <span className={`text-sm ${plan.highlighted ? 'text-white/70' : 'text-gray'}`}>/month</span>
                </div>
              </div>

              {/* Features */}
              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li
                    key={feature}
                    className="flex items-center gap-3"
                    style={{
                      animation: isVisible
                        ? `staggerPop 0.3s ${0.9 + index * 0.2 + featureIndex * 0.05}s cubic-bezier(0.68, -0.55, 0.265, 1.55) forwards`
                        : 'none',
                      opacity: 0,
                    }}
                  >
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                      plan.highlighted ? 'bg-primary' : 'bg-primary/10'
                    }`}>
                      <Check className={`w-3 h-3 ${plan.highlighted ? 'text-white' : 'text-primary'}`} />
                    </div>
                    <span className={`text-sm ${plan.highlighted ? 'text-white/90' : 'text-gray'}`}>
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>

              {/* CTA Button */}
              <Button
                className={`w-full py-6 rounded-xl font-semibold transition-all duration-300 hover:scale-105 ${
                  plan.highlighted
                    ? 'bg-primary hover:bg-white text-white hover:text-primary'
                    : 'bg-primary/10 hover:bg-secondary text-primary hover:text-white'
                }`}
              >
                {plan.cta}
              </Button>
            </div>
          ))}
        </div>

        {/* Bottom Note */}
        <div
          className="mt-12 text-center"
          style={{
            animation: isVisible ? 'fadeUp 0.8s 1s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
            opacity: 0,
          }}
        >
          <p className="text-gray text-sm">
            All plans include a 14-day free trial. No credit card required.{' '}
            <a href="#" className="text-primary hover:underline font-medium">
              Compare all features
            </a>
          </p>
        </div>
      </div>

      <style>{`
        @keyframes flipIn3D {
          from {
            opacity: 0;
            transform: rotateY(-90deg);
          }
          to {
            opacity: 1;
            transform: rotateY(0deg);
          }
        }
        
        @keyframes countUp {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes staggerPop {
          from {
            opacity: 0;
            transform: scale(0);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
      `}</style>
    </section>
  );
};

export default Pricing;
