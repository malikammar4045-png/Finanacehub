import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

const CTA = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      className="py-24 lg:py-36 bg-white overflow-hidden"
    >
      <div className="max-w-[1460px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden">
          {/* Background */}
          <div className="absolute inset-0 bg-secondary">
            {/* Gradient Mesh */}
            <div className="absolute inset-0 bg-gradient-to-br from-secondary via-secondary/95 to-primary/20" />
            
            {/* Animated Orbs */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 rounded-full blur-[120px] animate-float" />
            <div className="absolute bottom-0 left-0 w-80 h-80 bg-primary/15 rounded-full blur-[100px] animate-float" style={{ animationDelay: '-2s' }} />
            
            {/* Particles */}
            <div className="absolute inset-0 opacity-30">
              {[...Array(20)].map((_, i) => (
                <div
                  key={i}
                  className="absolute w-1 h-1 bg-white rounded-full animate-float"
                  style={{
                    left: `${Math.random() * 100}%`,
                    top: `${Math.random() * 100}%`,
                    animationDelay: `${Math.random() * 5}s`,
                    animationDuration: `${4 + Math.random() * 4}s`,
                  }}
                />
              ))}
            </div>
          </div>

          {/* Content */}
          <div className="relative z-10 grid lg:grid-cols-2 gap-12 items-center p-8 lg:p-16">
            {/* Left Content */}
            <div
              style={{
                animation: isVisible ? 'slideFromLeft 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
                opacity: 0,
              }}
            >
              <h2 className="text-3xl sm:text-4xl lg:text-h2 font-bold text-white mb-6">
                Ready to Start Your{' '}
                <span className="text-gradient">Investment Journey?</span>
              </h2>
              <p className="text-white/70 text-lg mb-8 max-w-lg">
                Join over 500,000 investors who trust FinanceHub to grow their wealth.
                Get started today with our 14-day free trial.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  onClick={() => scrollToSection('#pricing')}
                  className="bg-primary hover:bg-white text-white hover:text-primary px-8 py-6 rounded-full font-semibold text-lg transition-all duration-300 hover:scale-105 group animate-pulse-glow"
                >
                  Get Started Free
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
                <span className="text-white/50 text-sm flex items-center">
                  <Sparkles className="w-4 h-4 mr-2" />
                  No credit card required
                </span>
              </div>
            </div>

            {/* Right Image */}
            <div
              className="relative hidden lg:block"
              style={{
                animation: isVisible ? 'slideFromRight 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
                opacity: 0,
              }}
            >
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src="/images/cta-image.jpg"
                  alt="Investment success"
                  className="w-full h-auto object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-secondary/40 to-transparent" />
              </div>

              {/* Floating Badge */}
              <div
                className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-xl p-4 animate-float"
                style={{ animationDelay: '-1s' }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <svg className="w-6 h-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <div>
                    <div className="font-bold text-secondary">500K+</div>
                    <div className="text-sm text-gray">Happy Investors</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slideFromLeft {
          from {
            opacity: 0;
            transform: translateX(-100px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        
        @keyframes slideFromRight {
          from {
            opacity: 0;
            transform: translateX(100px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
      `}</style>
    </section>
  );
};

export default CTA;
