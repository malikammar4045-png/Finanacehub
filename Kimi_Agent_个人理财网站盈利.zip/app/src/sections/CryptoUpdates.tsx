import { useEffect, useRef, useState } from 'react';
import { TrendingUp, TrendingDown, Bitcoin, Cpu, Globe, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

const CryptoUpdates = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const cryptoData = [
    {
      name: 'Bitcoin',
      symbol: 'BTC',
      price: '$43,245.67',
      change: '+5.23%',
      isPositive: true,
      icon: Bitcoin,
      color: 'bg-orange-500',
    },
    {
      name: 'Ethereum',
      symbol: 'ETH',
      price: '$2,678.90',
      change: '+3.45%',
      isPositive: true,
      icon: Cpu,
      color: 'bg-blue-500',
    },
    {
      name: 'Solana',
      symbol: 'SOL',
      price: '$98.76',
      change: '-2.11%',
      isPositive: false,
      icon: Zap,
      color: 'bg-purple-500',
    },
    {
      name: 'Cardano',
      symbol: 'ADA',
      price: '$0.58',
      change: '+1.89%',
      isPositive: true,
      icon: Globe,
      color: 'bg-indigo-500',
    },
  ];

  const news = [
    {
      title: 'Bitcoin ETF Approval Drives Institutional Adoption',
      date: 'Jan 15, 2024',
      category: 'Market News',
    },
    {
      title: 'Ethereum 2.0 Staking Rewards Reach New Highs',
      date: 'Jan 14, 2024',
      category: 'Technology',
    },
    {
      title: 'Regulatory Clarity Boosts Crypto Market Sentiment',
      date: 'Jan 13, 2024',
      category: 'Regulation',
    },
  ];

  return (
    <section
      id="crypto"
      ref={sectionRef}
      className="py-24 lg:py-36 bg-white overflow-hidden"
    >
      <div className="max-w-[1460px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-16">
          <div className="max-w-xl mb-8 lg:mb-0">
            <span
              className="inline-block text-primary text-sm font-semibold tracking-wider uppercase mb-4"
              style={{
                animation: isVisible ? 'fadeUp 0.7s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
                opacity: 0,
              }}
            >
              Crypto Updates
            </span>
            <h2
              className="text-3xl sm:text-4xl lg:text-h2 font-bold text-secondary mb-6"
              style={{
                animation: isVisible ? 'fadeUp 0.7s 0.1s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
                opacity: 0,
              }}
            >
              Stay Ahead With{' '}
              <span className="text-gradient">Crypto Markets</span>
            </h2>
            <p
              className="text-gray text-lg"
              style={{
                animation: isVisible ? 'fadeUp 0.7s 0.2s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
                opacity: 0,
              }}
            >
              Real-time market data, expert analysis, and the latest news
              to help you make informed crypto investment decisions.
            </p>
          </div>

          <Button
            className="bg-primary hover:bg-secondary text-white px-6 py-3 rounded-full font-semibold transition-all duration-300 hover:scale-105 self-start lg:self-auto"
            style={{
              animation: isVisible ? 'fadeUp 0.7s 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            View All Markets
          </Button>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Crypto Prices */}
          <div
            className="bg-gray-light rounded-2xl p-6 lg:p-8"
            style={{
              animation: isVisible ? 'slideLeft 0.8s 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            <h3 className="text-xl font-bold text-secondary mb-6 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              Live Market Prices
            </h3>

            <div className="space-y-4">
              {cryptoData.map((crypto, index) => (
                <div
                  key={crypto.symbol}
                  className="bg-white rounded-xl p-4 flex items-center justify-between group hover:shadow-md transition-all duration-300 hover:-translate-y-1"
                  style={{
                    animation: isVisible
                      ? `fadeUp 0.5s ${0.4 + index * 0.1}s cubic-bezier(0.16, 1, 0.3, 1) forwards`
                      : 'none',
                    opacity: 0,
                  }}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 ${crypto.color} rounded-full flex items-center justify-center group-hover:scale-110 transition-transform`}>
                      <crypto.icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="font-bold text-secondary">{crypto.name}</div>
                      <div className="text-sm text-gray">{crypto.symbol}</div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="font-bold text-secondary">{crypto.price}</div>
                    <div className={`text-sm flex items-center justify-end gap-1 ${crypto.isPositive ? 'text-green-500' : 'text-red-500'}`}>
                      {crypto.isPositive ? (
                        <TrendingUp className="w-3 h-3" />
                      ) : (
                        <TrendingDown className="w-3 h-3" />
                      )}
                      {crypto.change}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* News Section */}
          <div
            className="bg-secondary rounded-2xl p-6 lg:p-8 text-white"
            style={{
              animation: isVisible ? 'slideRight 0.8s 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Globe className="w-5 h-5 text-primary" />
              Latest Crypto News
            </h3>

            <div className="space-y-6">
              {news.map((item, index) => (
                <div
                  key={item.title}
                  className="group cursor-pointer"
                  style={{
                    animation: isVisible
                      ? `fadeUp 0.5s ${0.5 + index * 0.1}s cubic-bezier(0.16, 1, 0.3, 1) forwards`
                      : 'none',
                    opacity: 0,
                  }}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-semibold text-primary bg-primary/20 px-2 py-1 rounded">
                      {item.category}
                    </span>
                    <span className="text-xs text-white/50">{item.date}</span>
                  </div>
                  <h4 className="font-semibold text-lg group-hover:text-primary transition-colors duration-300 leading-snug">
                    {item.title}
                  </h4>
                  <div className="mt-3 h-px bg-white/10" />
                </div>
              ))}
            </div>

            {/* Market Sentiment */}
            <div className="mt-8 pt-6 border-t border-white/10">
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm text-white/70">Market Sentiment</span>
                <span className="text-primary font-bold">Bullish</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-primary to-green-400 rounded-full"
                  style={{
                    width: '72%',
                    animation: isVisible ? 'growWidth 1s 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
                    transform: 'scaleX(0)',
                    transformOrigin: 'left',
                  }}
                />
              </div>
              <div className="flex justify-between mt-2 text-xs text-white/50">
                <span>Fear</span>
                <span>Greed</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slideLeft {
          from {
            opacity: 0;
            transform: translateX(-50px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        
        @keyframes slideRight {
          from {
            opacity: 0;
            transform: translateX(50px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        
        @keyframes growWidth {
          from {
            transform: scaleX(0);
          }
          to {
            transform: scaleX(1);
          }
        }
      `}</style>
    </section>
  );
};

export default CryptoUpdates;
