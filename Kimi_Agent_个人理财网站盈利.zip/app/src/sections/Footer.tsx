import { useEffect, useRef, useState } from 'react';
import { Send, Facebook, Instagram, Twitter, Linkedin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const Footer = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [email, setEmail] = useState('');
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const quickLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Pricing', href: '#pricing' },
    { name: 'Blog', href: '#blog' },
    { name: 'Contact', href: '#contact' },
  ];

  const supportLinks = [
    { name: 'Help Center', href: '#' },
    { name: 'FAQs', href: '#' },
    { name: 'Privacy Policy', href: '#' },
    { name: 'Terms of Service', href: '#' },
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
  ];

  const scrollToSection = (href: string) => {
    if (href.startsWith('#')) {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Thank you for subscribing with: ${email}`);
    setEmail('');
  };

  return (
    <footer
      ref={sectionRef}
      className="bg-secondary pt-20 pb-8 overflow-hidden"
    >
      <div className="max-w-[1460px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Border Animation */}
        <div
          className="h-px bg-gradient-to-r from-primary via-primary/50 to-primary mb-16"
          style={{
            animation: isVisible ? 'drawLine 1s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
            transform: 'scaleX(0)',
            transformOrigin: 'left',
          }}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8 mb-16">
          {/* Brand Column */}
          <div
            className="lg:col-span-1"
            style={{
              animation: isVisible ? 'fadeIn 0.6s 0.2s ease forwards' : 'none',
              opacity: 0,
            }}
          >
            <a href="#home" className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">F</span>
              </div>
              <span className="font-bold text-xl text-white">FinanceHub</span>
            </a>
            <p
              className="text-white/60 mb-6 leading-relaxed"
              style={{
                animation: isVisible ? 'fadeUp 0.6s 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
                opacity: 0,
              }}
            >
              Empowering everyone to invest with confidence through cutting-edge
              technology and expert guidance.
            </p>

            {/* Social Links */}
            <div className="flex gap-3">
              {socialLinks.map((social, index) => (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white/60 hover:bg-primary hover:border-primary hover:text-white transition-all duration-300 hover:-translate-y-1"
                  style={{
                    animation: isVisible
                      ? `popIn 0.4s ${0.6 + index * 0.1}s cubic-bezier(0.68, -0.55, 0.265, 1.55) forwards`
                      : 'none',
                    opacity: 0,
                  }}
                >
                  <social.icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div
            style={{
              animation: isVisible ? 'fadeUp 0.6s 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            <h4 className="text-white font-bold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li
                  key={link.name}
                  style={{
                    animation: isVisible
                      ? `staggerFade 0.4s ${0.5 + index * 0.08}s cubic-bezier(0.16, 1, 0.3, 1) forwards`
                      : 'none',
                    opacity: 0,
                  }}
                >
                  <a
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection(link.href);
                    }}
                    className="text-white/60 hover:text-primary transition-all duration-300 hover:translate-x-1 inline-block"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Links */}
          <div
            style={{
              animation: isVisible ? 'fadeUp 0.6s 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            <h4 className="text-white font-bold mb-6">Support</h4>
            <ul className="space-y-3">
              {supportLinks.map((link, index) => (
                <li
                  key={link.name}
                  style={{
                    animation: isVisible
                      ? `staggerFade 0.4s ${0.6 + index * 0.08}s cubic-bezier(0.16, 1, 0.3, 1) forwards`
                      : 'none',
                    opacity: 0,
                  }}
                >
                  <a
                    href={link.href}
                    className="text-white/60 hover:text-primary transition-all duration-300 hover:translate-x-1 inline-block"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div
            style={{
              animation: isVisible ? 'fadeUp 0.7s 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            <h4 className="text-white font-bold mb-6">Stay Updated</h4>
            <p className="text-white/60 mb-4 text-sm">
              Subscribe to our newsletter for the latest financial tips and market updates.
            </p>
            <form onSubmit={handleSubscribe} className="flex gap-2">
              <Input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder:text-white/40 focus:border-primary"
                required
              />
              <Button
                type="submit"
                className="bg-primary hover:bg-white text-white hover:text-primary px-4 transition-all duration-300"
              >
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </div>
        </div>

        {/* Bottom Bar */}
        <div
          className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4"
          style={{
            animation: isVisible ? 'fadeIn 0.5s 1s ease forwards' : 'none',
            opacity: 0,
          }}
        >
          <p className="text-white/40 text-sm">
            © 2024 FinanceHub. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm">
            <a href="#" className="text-white/40 hover:text-primary transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-white/40 hover:text-primary transition-colors">
              Terms of Service
            </a>
            <a href="#" className="text-white/40 hover:text-primary transition-colors">
              Cookies
            </a>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes drawLine {
          from {
            transform: scaleX(0);
          }
          to {
            transform: scaleX(1);
          }
        }
        
        @keyframes staggerFade {
          from {
            opacity: 0;
            transform: translateY(15px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes popIn {
          from {
            opacity: 0;
            transform: scale(0);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
      `}</style>
    </footer>
  );
};

export default Footer;
