import { useEffect, useRef, useState } from 'react';
import { Laptop, Camera, PenTool, Code, Headphones, BarChart3, ArrowRight, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

const SideHustle = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const hustles = [
    {
      icon: Laptop,
      title: 'Freelance Writing',
      description: 'Create content for blogs, websites, and businesses. Earn $50-$500 per article.',
      earnings: '$2K-5K/mo',
      difficulty: 'Beginner',
      color: 'bg-blue-500',
    },
    {
      icon: Code,
      title: 'Web Development',
      description: 'Build websites and apps for clients. High demand with excellent pay rates.',
      earnings: '$5K-15K/mo',
      difficulty: 'Intermediate',
      color: 'bg-purple-500',
    },
    {
      icon: Camera,
      title: 'Photography',
      description: 'Sell stock photos or offer portrait services. Turn your passion into profit.',
      earnings: '$1K-4K/mo',
      difficulty: 'Beginner',
      color: 'bg-pink-500',
    },
    {
      icon: PenTool,
      title: 'Graphic Design',
      description: 'Create logos, social media graphics, and marketing materials.',
      earnings: '$3K-8K/mo',
      difficulty: 'Intermediate',
      color: 'bg-orange-500',
    },
    {
      icon: Headphones,
      title: 'Online Tutoring',
      description: 'Teach subjects you are expert in. Flexible hours with steady income.',
      earnings: '$2K-6K/mo',
      difficulty: 'Beginner',
      color: 'bg-green-500',
    },
    {
      icon: BarChart3,
      title: 'Digital Marketing',
      description: 'Help businesses grow their online presence. High-value skill set.',
      earnings: '$4K-12K/mo',
      difficulty: 'Advanced',
      color: 'bg-red-500',
    },
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner':
        return 'text-green-500 bg-green-50';
      case 'Intermediate':
        return 'text-yellow-500 bg-yellow-50';
      case 'Advanced':
        return 'text-red-500 bg-red-50';
      default:
        return 'text-gray-500 bg-gray-50';
    }
  };

  return (
    <section
      id="sidehustle"
      ref={sectionRef}
      className="py-24 lg:py-36 bg-gray-light overflow-hidden"
    >
      <div className="max-w-[1460px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span
            className="inline-block text-primary text-sm font-semibold tracking-wider uppercase mb-4"
            style={{
              animation: isVisible ? 'fadeUp 0.7s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            Side Hustle Guides
          </span>
          <h2
            className="text-3xl sm:text-4xl lg:text-h2 font-bold text-secondary mb-6"
            style={{
              animation: isVisible ? 'fadeUp 0.7s 0.1s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            Boost Your Income With{' '}
            <span className="text-gradient">Side Hustles</span>
          </h2>
          <p
            className="text-gray text-lg"
            style={{
              animation: isVisible ? 'fadeUp 0.7s 0.2s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            Discover proven ways to earn extra income. From beginner-friendly
            options to high-skill opportunities, find the perfect side hustle for you.
          </p>
        </div>

        {/* Hustles Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {hustles.map((hustle, index) => (
            <div
              key={hustle.title}
              className="group bg-white rounded-2xl p-6 lg:p-8 shadow-sm hover:shadow-xl transition-all duration-500 hover:-translate-y-2"
              style={{
                animation: isVisible
                  ? `fadeUp 0.8s ${0.3 + index * 0.1}s cubic-bezier(0.16, 1, 0.3, 1) forwards`
                  : 'none',
                opacity: 0,
              }}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div
                  className={`w-14 h-14 ${hustle.color} rounded-xl flex items-center justify-center group-hover:scale-110 group-hover:rotate-3 transition-all duration-300`}
                >
                  <hustle.icon className="w-7 h-7 text-white" />
                </div>
                <span className={`text-xs font-semibold px-3 py-1 rounded-full ${getDifficultyColor(hustle.difficulty)}`}>
                  {hustle.difficulty}
                </span>
              </div>

              {/* Content */}
              <h3 className="text-xl font-bold text-secondary mb-2 group-hover:text-primary transition-colors duration-300">
                {hustle.title}
              </h3>
              <p className="text-gray text-sm leading-relaxed mb-4">
                {hustle.description}
              </p>

              {/* Earnings */}
              <div className="flex items-center gap-2 mb-4">
                <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                <span className="text-sm text-gray">Potential:</span>
                <span className="font-bold text-primary">{hustle.earnings}</span>
              </div>

              {/* CTA */}
              <Button
                variant="ghost"
                className="p-0 h-auto text-primary font-semibold hover:bg-transparent group/btn"
              >
                Get Started
                <ArrowRight className="w-4 h-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
              </Button>
            </div>
          ))}
        </div>

        {/* Bottom Stats */}
        <div
          className="mt-16 grid grid-cols-2 lg:grid-cols-4 gap-6"
          style={{
            animation: isVisible ? 'fadeUp 0.8s 0.9s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
            opacity: 0,
          }}
        >
          {[
            { value: '50+', label: 'Side Hustle Ideas' },
            { value: '$1.2B', label: 'Earned by Our Community' },
            { value: '89%', label: 'Success Rate' },
            { value: '4.9/5', label: 'User Rating' },
          ].map((stat) => (
            <div key={stat.label} className="text-center bg-white rounded-xl p-6">
              <div className="text-2xl lg:text-3xl font-bold text-primary mb-1">{stat.value}</div>
              <div className="text-sm text-gray">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SideHustle;
