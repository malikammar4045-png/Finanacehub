import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Calendar, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Blog = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const posts = [
    {
      image: '/images/blog1.jpg',
      category: 'Budgeting',
      title: '10 Proven Strategies to Save $1000 This Month',
      excerpt: 'Discover practical tips that actually work to boost your savings without sacrificing your lifestyle.',
      date: 'Jan 18, 2024',
      readTime: '5 min read',
    },
    {
      image: '/images/blog2.jpg',
      category: 'Crypto',
      title: 'Crypto Market Outlook: What to Expect in 2024',
      excerpt: 'Expert analysis on Bitcoin, Ethereum, and emerging altcoins for the coming year.',
      date: 'Jan 16, 2024',
      readTime: '8 min read',
    },
    {
      image: '/images/blog3.jpg',
      category: 'Side Hustle',
      title: 'How I Built a $5K/Month Side Business in 6 Months',
      excerpt: 'A step-by-step guide to launching your own profitable side hustle from scratch.',
      date: 'Jan 14, 2024',
      readTime: '6 min read',
    },
  ];

  return (
    <section
      ref={sectionRef}
      className="py-24 lg:py-36 bg-white overflow-hidden"
    >
      <div className="max-w-[1460px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-16">
          <div className="max-w-xl mb-8 lg:mb-0">
            <span
              className="inline-block text-primary text-sm font-semibold tracking-wider uppercase mb-4"
              style={{
                animation: isVisible ? 'fadeUp 0.7s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
                opacity: 0,
              }}
            >
              Latest News
            </span>
            <h2
              className="text-3xl sm:text-4xl lg:text-h2 font-bold text-secondary"
              style={{
                animation: isVisible ? 'fadeUp 0.7s 0.1s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
                opacity: 0,
              }}
            >
              Financial{' '}
              <span className="text-gradient">Insights & Updates</span>
            </h2>
          </div>

          <Button
            className="bg-primary hover:bg-secondary text-white px-6 py-3 rounded-full font-semibold transition-all duration-300 hover:scale-105 self-start lg:self-auto"
            style={{
              animation: isVisible ? 'fadeUp 0.7s 0.2s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            View All Articles
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>

        {/* Blog Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post, index) => (
            <article
              key={post.title}
              className="group cursor-pointer"
              style={{
                animation: isVisible
                  ? `riseRotate 0.8s ${0.2 + index * 0.15}s cubic-bezier(0.16, 1, 0.3, 1) forwards`
                  : 'none',
                opacity: 0,
              }}
            >
              {/* Image */}
              <div className="relative rounded-xl overflow-hidden mb-5 shadow-lg">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-secondary/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                {/* Category Badge */}
                <span className="absolute top-4 left-4 bg-primary text-white text-xs font-semibold px-3 py-1.5 rounded-full">
                  {post.category}
                </span>
              </div>

              {/* Content */}
              <div>
                {/* Meta */}
                <div className="flex items-center gap-4 text-sm text-gray mb-3">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    {post.date}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {post.readTime}
                  </span>
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-secondary mb-3 group-hover:text-primary transition-colors duration-300 line-clamp-2">
                  {post.title}
                </h3>

                {/* Excerpt */}
                <p className="text-gray text-sm leading-relaxed mb-4 line-clamp-2">
                  {post.excerpt}
                </p>

                {/* Read More */}
                <span className="inline-flex items-center text-primary font-semibold text-sm group-hover:gap-3 transition-all duration-300">
                  Read More
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </span>
              </div>
            </article>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes riseRotate {
          from {
            opacity: 0;
            transform: translateY(60px) rotateX(10deg);
          }
          to {
            opacity: 1;
            transform: translateY(0) rotateX(0deg);
          }
        }
      `}</style>
    </section>
  );
};

export default Blog;
