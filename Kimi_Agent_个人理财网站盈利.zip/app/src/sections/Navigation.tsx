import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface NavigationProps {
  scrollY: number;
}

const Navigation = ({ scrollY }: NavigationProps) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Budget Tips', href: '#budget' },
    { name: 'Crypto', href: '#crypto' },
    { name: 'Side Hustle', href: '#sidehustle' },
    { name: 'Pricing', href: '#pricing' },
  ];

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const isScrolled = scrollY > 50;

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-xl shadow-lg py-3'
          : 'bg-transparent py-5'
      }`}
      style={{
        animation: isVisible ? 'slideDown 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
      }}
    >
      <div className="max-w-[1460px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              scrollToSection('#home');
            }}
            className="flex items-center gap-2 group"
            style={{
              animation: isVisible ? 'fadeIn 0.6s 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards' : 'none',
              opacity: 0,
            }}
          >
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center transform group-hover:scale-110 transition-transform duration-300">
              <span className="text-white font-bold text-xl">F</span>
            </div>
            <span className={`font-bold text-xl transition-colors duration-300 ${isScrolled ? 'text-secondary' : 'text-white'}`}>
              FinanceHub
            </span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link, index) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection(link.href);
                }}
                className={`relative text-sm font-medium transition-all duration-300 hover:-translate-y-0.5 ${
                  isScrolled ? 'text-secondary' : 'text-white/90'
                } hover:text-primary group`}
                style={{
                  animation: isVisible ? `fadeIn 0.4s ${0.3 + index * 0.1}s cubic-bezier(0.16, 1, 0.3, 1) forwards` : 'none',
                  opacity: 0,
                }}
              >
                {link.name}
                <span className="absolute -bottom-1 left-1/2 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full group-hover:left-0" />
              </a>
            ))}
          </div>

          {/* CTA Button */}
          <div
            className="hidden lg:block"
            style={{
              animation: isVisible ? 'scaleIn 0.5s 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) forwards' : 'none',
              opacity: 0,
            }}
          >
            <Button
              onClick={() => scrollToSection('#pricing')}
              className="bg-primary hover:bg-secondary text-white px-6 py-2.5 rounded-full font-semibold transition-all duration-300 hover:scale-105 hover:shadow-[0_8px_24px_rgba(1,195,141,0.3)]"
            >
              Get Started
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? (
              <X className={`w-6 h-6 ${isScrolled ? 'text-secondary' : 'text-white'}`} />
            ) : (
              <Menu className={`w-6 h-6 ${isScrolled ? 'text-secondary' : 'text-white'}`} />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        <div
          className={`lg:hidden overflow-hidden transition-all duration-500 ${
            isMenuOpen ? 'max-h-96 opacity-100 mt-4' : 'max-h-0 opacity-0'
          }`}
        >
          <div className="bg-white rounded-2xl shadow-xl p-4 space-y-2">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection(link.href);
                }}
                className="block px-4 py-3 text-secondary hover:bg-primary/10 hover:text-primary rounded-lg transition-all duration-300 font-medium"
              >
                {link.name}
              </a>
            ))}
            <Button
              onClick={() => scrollToSection('#pricing')}
              className="w-full bg-primary hover:bg-secondary text-white py-3 rounded-lg font-semibold mt-2"
            >
              Get Started
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
