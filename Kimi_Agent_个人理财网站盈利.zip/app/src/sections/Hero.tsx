import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight, TrendingUp, Shield, Wallet } from 'lucide-react';

const Hero = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  // Particle animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    interface Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;
      opacity: number;
    }

    const particles: Particle[] = [];
    const particleCount = 40;

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        radius: Math.random() * 2 + 1,
        opacity: Math.random() * 0.5 + 0.3,
      });
    }

    let animationId: number;
    let frameCount = 0;

    const animate = () => {
      frameCount++;
      // Render every 2nd frame for performance (30fps)
      if (frameCount % 2 === 0) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        particles.forEach((particle, i) => {
          particle.x += particle.vx;
          particle.y += particle.vy;

          if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1;
          if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1;

          ctx.beginPath();
          ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(255, 255, 255, ${particle.opacity})`;
          ctx.fill();

          // Draw connections (only check every 5th particle for performance)
          if (i % 5 === 0) {
            particles.slice(i + 1).forEach((other) => {
              const dx = particle.x - other.x;
              const dy = particle.y - other.y;
              const distance = Math.sqrt(dx * dx + dy * dy);

              if (distance < 120) {
                ctx.beginPath();
                ctx.moveTo(particle.x, particle.y);
                ctx.lineTo(other.x, other.y);
                ctx.strokeStyle = `rgba(255, 255, 255, ${0.15 * (1 - distance / 120)})`;
                ctx.stroke();
              }
            });
          }
        });
      }

      animationId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationId);
    };
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-screen bg-secondary overflow-hidden flex items-center justify-center"
    >
      {/* Particle Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 z-0"
        style={{ opacity: isVisible ? 1 : 0, transition: 'opacity 1.5s ease' }}
      />

      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-secondary via-secondary/95 to-secondary z-[1]" />

      {/* Animated Gradient Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[120px] animate-float z-[1]" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary/15 rounded-full blur-[100px] animate-float z-[1]" style={{ animationDelay: '-2s' }} />

      {/* Content */}
      <div className="relative z-10 max-w-[900px] mx-auto px-4 sm:px-6 lg:px-8 text-center pt-24">
        {/* Subtitle */}
        <div
          className="inline-block mb-6"
          style={{
            animation: isVisible ? 'clipReveal 0.6s 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
            opacity: 0,
            clipPath: isVisible ? 'inset(0 0% 0 0)' : 'inset(0 100% 0 0)',
          }}
        >
          <span className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 border border-primary/30 rounded-full text-primary text-sm font-semibold tracking-wider uppercase">
            <TrendingUp className="w-4 h-4" />
            Investing Simplified
          </span>
        </div>

        {/* Title */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-h1 font-bold text-white mb-6 leading-tight">
          {['Grow', 'Your', 'Wealth', 'With', 'Confidence'].map((word, index) => (
            <span
              key={word}
              className="inline-block mr-3 sm:mr-4"
              style={{
                animation: isVisible
                  ? `splitRise 0.8s ${0.5 + index * 0.1}s cubic-bezier(0.16, 1, 0.3, 1) forwards`
                  : 'none',
                opacity: 0,
                transform: isVisible ? 'translateY(0) rotateX(0deg)' : 'translateY(60px) rotateX(30deg)',
              }}
            >
              {word === 'Wealth' ? (
                <span className="text-gradient">{word}</span>
              ) : (
                word
              )}
            </span>
          ))}
        </h1>

        {/* Description */}
        <p
          className="text-lg sm:text-xl text-white/70 max-w-2xl mx-auto mb-10"
          style={{
            animation: isVisible ? 'fadeBlur 0.7s 0.9s ease forwards' : 'none',
            opacity: 0,
            filter: isVisible ? 'blur(0)' : 'blur(10px)',
          }}
        >
          Expert-guided investment strategies tailored to your financial goals.
          Start building your future today with our comprehensive budget tips,
          crypto updates, and side-hustle guides.
        </p>

        {/* CTA Buttons */}
        <div
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16"
          style={{
            animation: isVisible ? 'bounceUp 0.6s 1.1s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards' : 'none',
            opacity: 0,
          }}
        >
          <Button
            onClick={() => scrollToSection('#pricing')}
            className="bg-primary hover:bg-white text-white hover:text-primary px-8 py-6 rounded-full font-semibold text-lg transition-all duration-300 hover:scale-105 hover:shadow-[0_0_30px_rgba(1,195,141,0.5)] group"
          >
            Start Investing
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
          <Button
            onClick={() => scrollToSection('#about')}
            variant="outline"
            className="border-white/30 text-white hover:bg-white/10 px-8 py-6 rounded-full font-semibold text-lg transition-all duration-300"
          >
            Learn More
          </Button>
        </div>

        {/* Stats */}
        <div
          className="grid grid-cols-3 gap-8 max-w-xl mx-auto"
          style={{
            animation: isVisible ? 'fadeUp 0.8s 1.3s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
            opacity: 0,
          }}
        >
          {[
            { icon: Wallet, value: '$2B+', label: 'Assets Managed' },
            { icon: Shield, value: '500K+', label: 'Active Investors' },
            { icon: TrendingUp, value: '15%', label: 'Avg. Returns' },
          ].map((stat, index) => (
            <div
              key={stat.label}
              className="text-center group"
              style={{ animationDelay: `${1.4 + index * 0.1}s` }}
            >
              <div className="flex justify-center mb-2">
                <stat.icon className="w-6 h-6 text-primary group-hover:scale-110 transition-transform" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-white mb-1">{stat.value}</div>
              <div className="text-xs sm:text-sm text-white/60">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Gradient Fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent z-10" />

      <style>{`
        @keyframes clipReveal {
          from {
            clip-path: inset(0 100% 0 0);
            opacity: 0;
          }
          to {
            clip-path: inset(0 0% 0 0);
            opacity: 1;
          }
        }
        
        @keyframes splitRise {
          from {
            opacity: 0;
            transform: translateY(60px) rotateX(30deg);
          }
          to {
            opacity: 1;
            transform: translateY(0) rotateX(0deg);
          }
        }
        
        @keyframes fadeBlur {
          from {
            opacity: 0;
            filter: blur(10px);
          }
          to {
            opacity: 1;
            filter: blur(0);
          }
        }
        
        @keyframes bounceUp {
          from {
            opacity: 0;
            transform: translateY(40px) scale(0.9);
          }
          50% {
            transform: translateY(-5px) scale(1.02);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
      `}</style>
    </section>
  );
};

export default Hero;
