import { useEffect, useRef, useState } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const Testimonials = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const testimonials = [
    {
      quote: "FinanceHub completely transformed how I manage my money. The budget tips alone helped me save an extra $400 per month. Highly recommend!",
      author: 'Sarah Mitchell',
      role: 'Marketing Manager',
      avatar: '/images/avatar1.jpg',
      rating: 5,
    },
    {
      quote: "The crypto updates are incredibly timely. I have made better investment decisions and seen a 23% return on my portfolio since joining.",
      author: 'James Rodriguez',
      role: 'Software Engineer',
      avatar: '/images/avatar2.jpg',
      rating: 5,
    },
    {
      quote: "Thanks to the side hustle guides, I started freelancing and now earn an extra $3,000 monthly. This platform is a game-changer!",
      author: 'Emily Chen',
      role: 'Graphic Designer',
      avatar: '/images/avatar3.jpg',
      rating: 5,
    },
    {
      quote: "The pricing is fair and the value is incredible. I have tried many finance apps, but FinanceHub is by far the most comprehensive.",
      author: 'Michael Johnson',
      role: 'Business Owner',
      avatar: '/images/avatar4.jpg',
      rating: 5,
    },
    {
      quote: "I love how everything is in one place - budgeting, crypto tracking, and side hustle ideas. It has simplified my financial life.",
      author: 'Amanda Foster',
      role: 'Teacher',
      avatar: '/images/avatar5.jpg',
      rating: 5,
    },
    {
      quote: "The customer support is exceptional. They helped me set up my investment strategy and I have already seen great results.",
      author: 'David Park',
      role: 'Medical Resident',
      avatar: '/images/avatar6.jpg',
      rating: 5,
    },
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % Math.ceil(testimonials.length / 3));
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + Math.ceil(testimonials.length / 3)) % Math.ceil(testimonials.length / 3));
  };

  const visibleTestimonials = testimonials.slice(currentSlide * 3, currentSlide * 3 + 3);

  return (
    <section
      ref={sectionRef}
      className="py-24 lg:py-36 bg-gray-light overflow-hidden"
    >
      <div className="max-w-[1460px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-16">
          <div>
            <span
              className="inline-block text-primary text-sm font-semibold tracking-wider uppercase mb-4"
              style={{
                animation: isVisible ? 'fadeUp 0.7s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
                opacity: 0,
              }}
            >
              Testimonials
            </span>
            <h2
              className="text-3xl sm:text-4xl lg:text-h2 font-bold text-secondary"
              style={{
                animation: isVisible ? 'fadeUp 0.7s 0.1s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
                opacity: 0,
              }}
            >
              What Our{' '}
              <span className="text-gradient">Investors Say</span>
            </h2>
          </div>

          {/* Navigation */}
          <div
            className="flex gap-3 mt-6 lg:mt-0"
            style={{
              animation: isVisible ? 'fadeIn 0.5s 0.8s ease forwards' : 'none',
              opacity: 0,
            }}
          >
            <button
              onClick={prevSlide}
              className="w-12 h-12 rounded-full bg-white shadow-md flex items-center justify-center text-secondary hover:bg-primary hover:text-white transition-all duration-300 hover:scale-110"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={nextSlide}
              className="w-12 h-12 rounded-full bg-white shadow-md flex items-center justify-center text-secondary hover:bg-primary hover:text-white transition-all duration-300 hover:scale-110"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {visibleTestimonials.map((testimonial, index) => (
            <div
              key={testimonial.author}
              className="group bg-white rounded-2xl p-6 lg:p-8 shadow-sm hover:shadow-xl transition-all duration-500 hover:-translate-y-2 relative"
              style={{
                animation: isVisible
                  ? `slideRotate 0.8s ${0.2 + index * 0.15}s cubic-bezier(0.16, 1, 0.3, 1) forwards`
                  : 'none',
                opacity: 0,
                transform: `rotate(${index === 0 ? '2' : index === 1 ? '-1' : '1'}deg)`,
              }}
            >
              {/* Quote Icon */}
              <div className="absolute top-4 right-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <Quote className="w-12 h-12 text-primary" />
              </div>

              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-4 h-4 text-primary fill-primary"
                    style={{
                      animation: isVisible
                        ? `starTwinkle 1s ${0.5 + i * 0.2}s ease forwards`
                        : 'none',
                    }}
                  />
                ))}
              </div>

              {/* Quote */}
              <p className="text-secondary leading-relaxed mb-6 relative z-10">
                "{testimonial.quote}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.author}
                  className="w-12 h-12 rounded-full object-cover ring-2 ring-primary/20"
                />
                <div>
                  <div className="font-semibold text-secondary">{testimonial.author}</div>
                  <div className="text-sm text-gray">{testimonial.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Dots Indicator */}
        <div className="flex justify-center gap-2 mt-8">
          {[...Array(Math.ceil(testimonials.length / 3))].map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                currentSlide === index ? 'w-8 bg-primary' : 'bg-secondary/20 hover:bg-secondary/40'
              }`}
            />
          ))}
        </div>
      </div>

      <style>{`
        @keyframes slideRotate {
          from {
            opacity: 0;
            transform: translateX(100px) rotate(5deg);
          }
          to {
            opacity: 1;
            transform: translateX(0) rotate(var(--rotation, 0deg));
          }
        }
        
        @keyframes starTwinkle {
          0%, 100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.2);
          }
        }
      `}</style>
    </section>
  );
};

export default Testimonials;
