import { useEffect, useRef, useState } from 'react';

const HowItWorks = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const steps = [
    {
      number: '01',
      title: 'Create Your Account',
      description: 'Sign up in minutes with our streamlined onboarding process. No complicated paperwork, just your basic information and you are ready to go.',
      image: '/images/step1-image.jpg',
    },
    {
      number: '02',
      title: 'Set Your Goals',
      description: 'Define your financial objectives and risk tolerance. Our smart questionnaire helps us understand what matters most to you.',
      image: '/images/step2-image.jpg',
    },
    {
      number: '03',
      title: 'Watch It Grow',
      description: 'Our AI-powered platform optimizes your portfolio automatically. Sit back and watch your investments work for you.',
      image: '/images/step3-image.jpg',
    },
  ];

  return (
    <section
      ref={sectionRef}
      className="py-24 lg:py-36 bg-white overflow-hidden"
    >
      <div className="max-w-[1460px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 lg:mb-24">
          <span
            className="inline-block text-primary text-sm font-semibold tracking-wider uppercase mb-4"
            style={{
              animation: isVisible ? 'fadeUp 0.7s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            How It Works
          </span>
          <h2
            className="text-3xl sm:text-4xl lg:text-h2 font-bold text-secondary"
            style={{
              animation: isVisible ? 'fadeUp 0.7s 0.1s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            Start Investing In{' '}
            <span className="text-gradient">3 Simple Steps</span>
          </h2>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Connecting Line */}
          <div
            className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-secondary/10 -translate-y-1/2"
            style={{
              animation: isVisible ? 'drawLine 1s 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              transform: 'scaleX(0)',
              transformOrigin: 'center',
            }}
          />

          {/* Steps */}
          <div className="grid lg:grid-cols-3 gap-8 lg:gap-12">
            {steps.map((step, index) => (
              <div
                key={step.number}
                className="relative group"
                style={{
                  animation: isVisible
                    ? `fadeUp 0.8s ${0.5 + index * 0.2}s cubic-bezier(0.16, 1, 0.3, 1) forwards`
                    : 'none',
                  opacity: 0,
                }}
              >
                {/* Step Number */}
                <div className="flex items-center justify-center mb-6">
                  <div
                    className="w-16 h-16 rounded-full bg-primary text-white flex items-center justify-center text-2xl font-bold shadow-lg shadow-primary/30 group-hover:scale-110 group-hover:shadow-primary/50 transition-all duration-300"
                    style={{
                      animation: isVisible
                        ? `countUp 0.6s ${0.5 + index * 0.2}s cubic-bezier(0.68, -0.55, 0.265, 1.55) forwards, glowPulse 3s ${1 + index * 0.5}s infinite`
                        : 'none',
                    }}
                  >
                    {step.number}
                  </div>
                </div>

                {/* Image */}
                <div className="relative rounded-xl overflow-hidden mb-6 shadow-lg group-hover:shadow-xl transition-shadow duration-300">
                  <img
                    src={step.image}
                    alt={step.title}
                    className="w-full h-48 lg:h-56 object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-secondary/30 to-transparent" />
                </div>

                {/* Content */}
                <div className="text-center">
                  <h3 className="text-xl lg:text-h4 font-bold text-secondary mb-3 group-hover:text-primary transition-colors duration-300">
                    {step.title}
                  </h3>
                  <p className="text-gray leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes drawLine {
          from {
            transform: scaleX(0) translateY(-50%);
          }
          to {
            transform: scaleX(1) translateY(-50%);
          }
        }
        
        @keyframes countUp {
          from {
            opacity: 0;
            transform: scale(0.5);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
        
        @keyframes glowPulse {
          0%, 100% {
            box-shadow: 0 0 0 rgba(1, 195, 141, 0.3);
          }
          50% {
            box-shadow: 0 0 30px rgba(1, 195, 141, 0.5);
          }
        }
      `}</style>
    </section>
  );
};

export default HowItWorks;
