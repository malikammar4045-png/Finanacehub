import { useEffect, useRef, useState } from 'react';
import { PiggyBank, TrendingDown, Calendar, Wallet, Calculator, Target } from 'lucide-react';

const BudgetTips = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const tips = [
    {
      icon: PiggyBank,
      title: '50/30/20 Rule',
      description: 'Allocate 50% to needs, 30% to wants, and 20% to savings. This simple framework helps you maintain balance.',
      color: 'bg-blue-500',
    },
    {
      icon: TrendingDown,
      title: 'Track Every Expense',
      description: 'Monitor your spending daily. Small purchases add up quickly - awareness is the first step to control.',
      color: 'bg-red-500',
    },
    {
      icon: Calendar,
      title: 'Automate Savings',
      description: 'Set up automatic transfers on payday. Pay yourself first before spending on discretionary items.',
      color: 'bg-green-500',
    },
    {
      icon: Wallet,
      title: 'Emergency Fund',
      description: 'Build 3-6 months of expenses in a liquid account. This safety net prevents debt during emergencies.',
      color: 'bg-purple-500',
    },
    {
      icon: Calculator,
      title: 'Zero-Based Budget',
      description: 'Give every dollar a job. Income minus expenses should equal zero - every penny is allocated.',
      color: 'bg-orange-500',
    },
    {
      icon: Target,
      title: 'Set SMART Goals',
      description: 'Specific, Measurable, Achievable, Relevant, Time-bound goals keep you motivated and on track.',
      color: 'bg-pink-500',
    },
  ];

  return (
    <section
      id="budget"
      ref={sectionRef}
      className="py-24 lg:py-36 bg-gray-light overflow-hidden"
    >
      <div className="max-w-[1460px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span
            className="inline-block text-primary text-sm font-semibold tracking-wider uppercase mb-4"
            style={{
              animation: isVisible ? 'fadeUp 0.7s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            Budget Tips
          </span>
          <h2
            className="text-3xl sm:text-4xl lg:text-h2 font-bold text-secondary mb-6"
            style={{
              animation: isVisible ? 'fadeUp 0.7s 0.1s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            Master Your{' '}
            <span className="text-gradient">Personal Finance</span>
          </h2>
          <p
            className="text-gray text-lg"
            style={{
              animation: isVisible ? 'fadeUp 0.7s 0.2s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
              opacity: 0,
            }}
          >
            Smart budgeting strategies to help you save more, spend wisely,
            and achieve your financial goals faster.
          </p>
        </div>

        {/* Tips Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {tips.map((tip, index) => (
            <div
              key={tip.title}
              className="group bg-white rounded-2xl p-6 lg:p-8 shadow-sm hover:shadow-xl transition-all duration-500 hover:-translate-y-2"
              style={{
                animation: isVisible
                  ? `fadeUp 0.8s ${0.3 + index * 0.1}s cubic-bezier(0.16, 1, 0.3, 1) forwards`
                  : 'none',
                opacity: 0,
              }}
            >
              {/* Icon */}
              <div
                className={`w-14 h-14 ${tip.color} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-3 transition-all duration-300`}
              >
                <tip.icon className="w-7 h-7 text-white" />
              </div>

              {/* Content */}
              <h3 className="text-xl font-bold text-secondary mb-3 group-hover:text-primary transition-colors duration-300">
                {tip.title}
              </h3>
              <p className="text-gray leading-relaxed">
                {tip.description}
              </p>

              {/* Hover Arrow */}
              <div className="mt-6 flex items-center text-primary font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <span className="text-sm">Learn More</span>
                <svg
                  className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div
          className="mt-16 text-center"
          style={{
            animation: isVisible ? 'fadeUp 0.8s 0.9s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
            opacity: 0,
          }}
        >
          <div className="inline-flex items-center gap-4 bg-white rounded-full px-6 py-3 shadow-md">
            <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
              <PiggyBank className="w-5 h-5 text-primary" />
            </div>
            <span className="text-secondary font-medium">
              Start saving an average of <span className="text-primary font-bold">$500/month</span> with these tips
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BudgetTips;
