import { useEffect, useRef, useState } from 'react';

const BrandLogos = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const brands = [
    { name: 'Bloomberg', svg: 'M6 4h2v16H6V4zm4 0h2v16h-2V4zm4 0h4a4 4 0 014 4v8a4 4 0 01-4 4h-4V4zm2 2v12h2a2 2 0 002-2V8a2 2 0 00-2-2h-2z' },
    { name: 'Forbes', svg: 'M4 4h16v4h-6v12h-4V8H4V4zm8 6h6v2h-6v-2zm0 4h6v2h-6v-2z' },
    { name: 'CNBC', svg: 'M2 4h20v16H2V4zm4 4v8h4V8H6zm6 0v8h4V8h-4zm6 0v8h4V8h-4z' },
    { name: 'Reuters', svg: 'M4 4h16v4H8v3h12v3H8v3h12v3H4V4z' },
    { name: 'WSJ', svg: 'M3 4h18v16H3V4zm3 3v10h3V7H6zm5 0v10h3V7h-3zm5 0v10h3V7h-3z' },
  ];

  return (
    <section
      ref={sectionRef}
      className="py-16 bg-white border-b border-secondary/10 overflow-hidden"
    >
      <div className="max-w-[1460px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title */}
        <p
          className="text-center text-gray text-sm font-medium mb-10 uppercase tracking-wider"
          style={{
            animation: isVisible ? 'fadeUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
            opacity: 0,
          }}
        >
          Trusted by leading financial institutions
        </p>

        {/* Logo Track */}
        <div
          className="relative"
          style={{
            animation: isVisible ? 'slideIn 0.8s 0.2s cubic-bezier(0.16, 1, 0.3, 1) forwards' : 'none',
            opacity: 0,
          }}
        >
          <div className="flex animate-scroll hover:[animation-play-state:paused]">
            {/* First set */}
            {[...brands, ...brands].map((brand, index) => (
              <div
                key={`${brand.name}-${index}`}
                className="flex-shrink-0 mx-12 group"
              >
                <div className="flex items-center gap-3 grayscale hover:grayscale-0 transition-all duration-300 hover:scale-110">
                  <svg
                    viewBox="0 0 24 24"
                    className="w-10 h-10 fill-secondary/60 group-hover:fill-primary transition-colors duration-300"
                  >
                    <path d={brand.svg} />
                  </svg>
                  <span className="text-xl font-bold text-secondary/60 group-hover:text-primary transition-colors duration-300">
                    {brand.name}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateX(100px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
      `}</style>
    </section>
  );
};

export default BrandLogos;
