import { useEffect, useState } from 'react';
import Navigation from './sections/Navigation';
import Hero from './sections/Hero';
import BrandLogos from './sections/BrandLogos';
import About from './sections/About';
import HowItWorks from './sections/HowItWorks';
import BudgetTips from './sections/BudgetTips';
import CryptoUpdates from './sections/CryptoUpdates';
import SideHustle from './sections/SideHustle';
import Pricing from './sections/Pricing';
import Testimonials from './sections/Testimonials';
import Blog from './sections/Blog';
import CTA from './sections/CTA';
import Footer from './sections/Footer';

function App() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      <Navigation scrollY={scrollY} />
      <Hero />
      <BrandLogos />
      <About />
      <HowItWorks />
      <BudgetTips />
      <CryptoUpdates />
      <SideHustle />
      <Pricing />
      <Testimonials />
      <Blog />
      <CTA />
      <Footer />
    </div>
  );
}

export default App;
